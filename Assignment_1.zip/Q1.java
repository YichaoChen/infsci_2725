
import org.bson.Document;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Q1 {
	
	public static void main(String[] args){
		StringBuffer buffer = new StringBuffer();
		try{
			MongoClient mongoClient = new MongoClient("localhost",27017);
			MongoDatabase db = mongoClient.getDatabase("local");
			MongoCollection<Document> movies = db.getCollection("movies");
			
			FindIterable<Document> findMovie = movies.find(new Document("Title", "Copycat (1995)"));//Find the movie whose title is Copycat (1995) in the collection
			findMovie.forEach(new Block<Document>(){
				public void apply(final Document document){	
					buffer.append("Title: "+document.get("Title")).append("   ");//Output the Title and the genres of this movie.
					buffer.append("Genres: "+document.get("Genres")).append("\n");					
				}
			});
			
			System.out.println(buffer.toString());
			
		}catch(Exception e){			
			  e.printStackTrace();
		}
	}
}
