
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;

import org.bson.Document;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Q2 {

	public static void main(String[] args){
		StringBuffer buffer = new StringBuffer();
		try{
			
			MongoClient mongoClient = new MongoClient("localhost",27017);
			MongoDatabase db = mongoClient.getDatabase("local");
			MongoCollection<Document> movies = db.getCollection("movies");
			
			FindIterable<Document> findMovie = movies.find();
			findMovie.forEach(new Block<Document>(){
				
				public void apply(final Document document){	
					buffer.append(document.get("Genres")).append(" "); //Get all genres from the "movies" collection and put them in a string buffer.		
				}
			});
			
			String genre = buffer.toString(); // Transform this string buffer into string. 
            
            Map<String,Integer> map = new HashMap<String, Integer>();
            StringTokenizer st = new StringTokenizer(genre);

            while (st.hasMoreTokens()) {
                                    
                String word = st.nextToken(",|\\[|\\]| ");  //Split the string by these notations.
                if(map.containsKey(word)){     //If the set has the key(name of the genre), then add one at this genre's count.
                    int count = map.get(word);  
                    map.put(word, count+1);      
                }else{                         //If the set does not have the key(name of the genre), create one then insert it into the set.
                    map.put(word, 1);
                }           
            }
            
            sort(map);
   		
		}catch(Exception e){
			
			  e.printStackTrace();
		}
	}
	

	public static void sort(Map<String,Integer> map){ //Sort the count values of each genre in the set.
	    List<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(map.entrySet());   
	    Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {     
	        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {     
	            return (o2.getValue() - o1.getValue());     
	        }     
	    });  
	    for (int i = 0; i < 1; i++) { // Output the rank #1.   
	        Entry<String, Integer> id = infoIds.get(i);  
	    System.out.println("The ["+id.getKey()+"] genre has the most movies, which has "+id.getValue()+" movies");  
	    }  
	}  

}
