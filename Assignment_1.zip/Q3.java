
import org.bson.Document;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Q3 {

	public static void main(String[] args) {
		StringBuffer buffer = new StringBuffer();
		StringBuffer buffer1 = new StringBuffer();
		
		try{
			
			MongoClient mongoClient = new MongoClient("localhost",27017);
			MongoDatabase db = mongoClient.getDatabase("local");
			MongoCollection<Document> tags = db.getCollection("tags");
			MongoCollection<Document> movies = db.getCollection("movies");

			
			
			FindIterable<Document> findMovie = movies.find(new Document("Title", "2001: A Space Odyssey (1968)"));//Find the movie in the collection
			findMovie.forEach(new Block<Document>(){				
				public void apply(final Document document1){
					
					buffer.append(document1.get("MovieID"));//Get the MovieID of this movie.					
					String movieID=buffer.toString();
					System.out.println("MovieID:" + movieID);
						FindIterable<Document> findUser = tags.find(new Document("UserID","146").append("MovieID",movieID)); //Use the UserID and the MovieID to find tags of this movie in tags collection.
						findUser.forEach(new Block<Document>(){	
							
							 public void apply(final Document document2){						 
									 buffer1.append("Tag: "+document2.get("Tag")).append("\n");	// Get the tags								 
							 }							 
						});						
				}
			});
			
			System.out.println(buffer1.toString()); 
			
		}catch(Exception e){
			
			  e.printStackTrace();
		}
	}

}
