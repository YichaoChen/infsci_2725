
import static java.util.Arrays.asList;

import org.bson.Document;
import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
public class Q4 {

	public static void main(String[] args) {
		
		StringBuffer buffer = new StringBuffer();
		StringBuffer buffer1 = new StringBuffer();
		try{
			
			MongoClient mongoClient = new MongoClient("localhost",27017);
			MongoDatabase db = mongoClient.getDatabase("local");
			MongoCollection<Document> ratings = db.getCollection("ratings");
			MongoCollection<Document> movies = db.getCollection("movies");
			
			//Compute the average rating of each movie in "ratings" collection after grouping.
			AggregateIterable<Document> avg = ratings.aggregate(asList(
					new Document("$group", new Document("_id", "$MovieID").append("avgRating", new Document("$avg", "$Rating")))));
			
			avg.forEach(new Block<Document>(){
				public void apply(final Document document1){
					//Find out the id of each movie based on the former groping.
					FindIterable<Document> findMovie = movies.find(new Document("MovieID",document1.get("_id")));
					findMovie.forEach(new Block<Document>(){
						public void apply(final Document document2){
							buffer.append("Title: "+document2.get("Title")).append("   ");
							buffer.append("AvgRating: "+document1.get("avgRating")).append("\n");
							
							//Create a new collection for average rating storage.
							db.getCollection("AverageRating").insertOne(new Document("Title",
				        			document2.get("Title")).append("AvgRating",document1.getDouble("avgRating")));
							
							
						}
					});
				}
			});
			
			MongoCollection<Document> AverageRating = db.getCollection("AverageRating");
			//Sort the result retrieved from the collection.
			FindIterable<Document> sortAvg = AverageRating.find().sort(new Document("AvgRating", -1));
			sortAvg.forEach(new Block<Document>(){
				public void apply(final Document document1){
					buffer1.append("Title: "+document1.get("Title")).append("   ");
					buffer1.append("AvgRating: "+document1.get("AvgRating")).append("\n");
				}
			});
						
			System.out.println(buffer1.toString());
						
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
