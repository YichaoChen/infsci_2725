import static java.util.Arrays.asList;

import org.bson.Document;

import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Q5 {

	public static void main(String[] args) {
		StringBuffer buffer = new StringBuffer();
		StringBuffer buffer1 = new StringBuffer();
		try{
			
			MongoClient mongoClient = new MongoClient("localhost",27017);
			MongoDatabase db = mongoClient.getDatabase("local");
			//We create "AverageRating" collection when doing Q4, so this time we can use it directly.
			MongoCollection<Document> AverageRating = db.getCollection("AverageRating");
			//Sort the result retrieved from the collection. 
			FindIterable<Document> sortAvg = AverageRating.find().sort(new Document("AvgRating", -1));
			sortAvg.forEach(new Block<Document>(){
				public void apply(final Document document1){
					buffer1.append("Title: "+document1.get("Title")).append("   ");
					buffer1.append("AvgRating: "+document1.get("AvgRating")).append("\n");
				}
			});
						
			System.out.println(buffer1.toString());
						
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
