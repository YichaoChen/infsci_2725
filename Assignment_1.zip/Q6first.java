import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Q6first {

	public static void main(String[] args) {

		List<String> userList = new ArrayList<String>();
		StringBuffer buffer = new StringBuffer();
		try{
			//Get the userID from input.
		    System.out.println("Enter the userID to see all the movies he/she rated");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			final String userID = br.readLine();
			
			MongoClient mongoClient = new MongoClient("localhost",27017);
			MongoDatabase db = mongoClient.getDatabase("local");
			MongoCollection<Document> rating = db.getCollection("ratings");
			MongoCollection<Document> movie = db.getCollection("movies");
			
			FindIterable<Document> findUser = rating.find(new Document("UserID", userID));
			
			findUser.forEach(new Block<Document>(){				
			  
			  public void apply(final Document document1){

				 FindIterable<Document> findMovie = movie.find(new Document("MovieID",document1.get("MovieID")));					
					findMovie.forEach(new Block<Document>(){
						
						public void apply(final Document document2){
							
							//Add the Title and the Genres to the buffer which will be print out later. 
							buffer.append("Title: "+document2.get("Title")).append("   ");
							buffer.append("Genres: "+document2.get("Genres")).append("\n");
						
						 }
				    });						
			 }
		 });
			   System.out.println(buffer.toString());
		}catch(Exception e){
			
		  e.printStackTrace();
		}

	}


}
