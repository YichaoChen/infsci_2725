import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.bson.Document;

import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Q6third {
	
	static int num;

	public static void main(String[] args){
		StringBuffer buffer = new StringBuffer();
		try{
			System.out.println("Enter the number x to genre's ranking from 1 to x");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			final String number = br.readLine();
			num = Integer.parseInt(number);// Get the input number.
			
			MongoClient mongoClient = new MongoClient("localhost",27017);
			MongoDatabase db = mongoClient.getDatabase("local");
			MongoCollection<Document> movies = db.getCollection("movies");
			
			FindIterable<Document> findMovie = movies.find();
			findMovie.forEach(new Block<Document>(){
				
				public void apply(final Document document){	
					buffer.append(document.get("Genres")).append(" ");				
				}
			});
			
			String genre = buffer.toString();
            
            Map<String,Integer> map = new HashMap<String, Integer>();
            StringTokenizer st = new StringTokenizer(genre);

            while (st.hasMoreTokens()) {
                                    
                String word = st.nextToken(",|\\[|\\]| ");  
                if(map.containsKey(word)){     
                    int count = map.get(word);  
                    map.put(word, count+1);     
                }else{  
                    map.put(word, 1);
                }           
            }

            
            sort(map);
            


			
		}catch(Exception e){
			
			  e.printStackTrace();
		}
	}
	
	
	public static void sort(Map<String,Integer> map){  
	    List<Map.Entry<String, Integer>> infoIds = new ArrayList<Map.Entry<String, Integer>>(map.entrySet());   
	    Collections.sort(infoIds, new Comparator<Map.Entry<String, Integer>>() {     
	        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {     
	            return (o2.getValue() - o1.getValue());     
	        }     
	    });  
	    for (int i = 0; i < num; i++) {    
	        Entry<String, Integer> id = infoIds.get(i);  
	    System.out.println("The ["+id.getKey()+"] genre has "+id.getValue()+" movies");  
	    }  
	}  

	
}
