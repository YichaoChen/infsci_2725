MyData <- read.csv(file="c:/Users/Jyee/Desktop/train.csv", header=TRUE, sep=",")
library(ggplot2)

# "sibsp" is "Number of Siblings/Spouses Aboard", "parch" is "Number of Parents/Children Aboard"
# get aboarded family size of each passenger
MyData$Family <- 1 + MyData$SibSp + MyData$Parch

# group "Survived" into two groups: 1 and 0 
MyData$Survived = as.factor(MyData$Survived)


# a. Whisker-plot
  # relationship between survived people and their age
ggplot(MyData, aes(Survived, Age)) + geom_boxplot() + theme_bw()
  # relationship between survived people and their fare rate
ggplot(MyData, aes(Survived, Fare)) + geom_boxplot() + theme_bw()


# b. Histogram
  # distribution of age
ggplot(MyData, aes(x = Age)) + geom_histogram(binwidth = 2) + theme_bw()
  # distribution of family size
ggplot(MyData, aes(x = Family)) + geom_histogram(binwidth = 1) + theme_bw()


# c. Facet grid
  # comparison of the Sex of the survived people
ggplot(MyData, aes(x = Survived, fill = Sex)) + geom_bar() + facet_grid(Sex ~ .) + theme_bw()
  # comparison of the Pclass of the survived people
ggplot(MyData, aes(x = Survived, fill = Pclass)) + geom_bar() + facet_grid(Pclass ~ .) + theme_bw()


# d. Violin plot
  # density of the Age of the survived people
ggplot(MyData, aes(Survived, Age)) + geom_violin() + theme_bw()
  # density of the Fare of the survived people
ggplot(MyData, aes(Survived, Fare)) + geom_violin() + theme_bw()


# e. Heatmap
cleanMyData <- MyData[which((MyData$Survived==1)&(!is.na(MyData$Age))),]
cleanMyData <- MyData[order(MyData$PassengerId), ]
row.names(cleanMyData) <- cleanMyData$PassengerId
cleanMyData <- cleanMyData[,c(3, 5, 6, 10)]
MyData_matrix <- data.matrix(cleanMyData)
MyData_heatmap <- heatmap(MyData_matrix, Rowv = NA, Colv = NA, col = heat.colors(256, alpha = 1), scale = "column", margins = c(5, 10))


